<?php
/* 
Plugin Name: پلاگین دسترسی به دیتابیس ::هوم ورک4 
Description: بسازید البته با پسوند پیشفرض دیتابیس برای کار با این پلاگین یک جدول با این نام mytable
Author: Farzan Niruomand
Version: 1.0.0.
Author URI: farzan_nirumand@yahoo.com
*/
echo "این فقط یک افزونه نیست، این نشان‌دهنده امید و شور و شوق یک نسل به طور خلاصه در دو کلمه است که توسط فرد مشهور، لوئیس آرمسترانگ سروده شده است: سلام، عزیزم. هنگامی که شما آن را فعال کنید، به صورت تصادفی یک متن از آهنگ سلام، عزیزم در گوشه چپ هر صفحه در بخش مدیریت مشاهده می‌کنید.";
define('PLUGIN_DIRHW4',plugin_dir_path(__FILE__));
define('PLUGIN_INCHW4',PLUGIN_DIRHW4 . '/inc/');
define('PLUGIN_TMPHW4',PLUGIN_DIRHW4 . '/tmp/');


if (is_admin())
{
    include PLUGIN_INCHW4 . 'admin/menu.php';
}
