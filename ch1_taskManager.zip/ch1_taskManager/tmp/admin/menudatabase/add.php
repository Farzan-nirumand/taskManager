<div class = "wrap">
<h3>  اطلاعات مربوط به وظیفه جدید را وارد کنید</h3>
<form action= "" method = "post">
<table class="form_table">

<tr valgin="top">
<th scop="row"> عنوان </th>
<td>
<input   type= "textbox" name= "textbox1" >
</td>
</tr>

<tr valgin="top">
<th scop="row"> شرح </th>
<td>
<input   type= "textbox" name= "textbox2">
</td>
</tr>

<tr valgin="top">
<th scop="row"> مهلت انجام (روز) </th>
<td>
<input   type= "textbox" name= "textbox3" >
</td>
</tr>


<tr valgin="top">
<th scop="row">  </th>
<td>
<input   type= "submit" name= "submit1" class="button" value="ذخیره سازی"/>
</td>
</tr>

</table>
</form>
</div>
